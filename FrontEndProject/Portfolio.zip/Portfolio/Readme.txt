Q: What does the Project do?
A: The project is a portfolio website that show projects that I have worked on

Q: How do you use it?
A: Open the index.html file in your browser

Q: How do you make sure it works?
A: If it loads in your browser with no errors it works!

Q: How to get involved?
A: There is contact information in the footer of the website